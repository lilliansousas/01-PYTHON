# Lista de tuplas com os resultados das equipes (exemplo)
resultados = [
    ("Equipe A", [10, 20, 30]),
    ("Equipe B", [15, 25, 35]),
    ("Equipe C", [5, 10, 15]),
]

# 1. Calcular a média das pontuações de cada equipe
medias = [(nome, sum(pontos) / len(pontos)) for nome, pontos in resultados]

# 2. Ordenar a lista medias em ordem decrescente
medias_ordenadas = sorted(medias, key=lambda x: x[1], reverse=True)

# 3. Criar a nova lista classificacao com as tuplas (nome da equipe, média)
classificacao = medias_ordenadas

# 4. Exibir a classificação final das equipes
print("Classificação final das equipes:")
for nome, media in classificacao:
    print(f"{nome}: {media:.2f}")

